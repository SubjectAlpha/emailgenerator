from . import main

if __name__ == "__name__":
    main()