# emailgenerator

This will generate a text file of emails based on the most popular first names and surnames in the US as well as include numbers such as birth/graduation year from 1950-2050 as well as include numbers in a 0-100 format.

-   You can supply your own domains, but gmail, hotmail, and outlook will be used if none are supplied

## Installation

-   [Clone from Github](https://github.com/SubjectAlpha/emailgenerator)
-   [Download from PyPi](https://pypi.org/project/emailgenerator/)

## Usage

![help image](imgs/help.png)
